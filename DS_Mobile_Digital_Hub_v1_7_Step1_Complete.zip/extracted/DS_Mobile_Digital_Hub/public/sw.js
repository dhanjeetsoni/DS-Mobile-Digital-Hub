const CACHE_NAME = "ds-mobile-runtime-v2";
const CORE_ASSETS = ["/", "/index.html", "/manifest.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS).catch(() => {})));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    try {
      const response = await fetch(event.request);
      if (response.ok && (url.pathname.startsWith("/assets/") ||
          url.pathname.endsWith(".js") || url.pathname.endsWith(".css") ||
          url.pathname.endsWith(".html") || url.pathname.endsWith(".json") ||
          url.pathname.endsWith(".wasm") || url.pathname.endsWith(".png") ||
          url.pathname.endsWith(".svg") || url.pathname.endsWith(".ico"))) {
        const cache = await caches.open(CACHE_NAME);
        cache.put(event.request, response.clone()).catch(() => {});
      }
      return response;
    } catch {
      if (cached) return cached;
      if (event.request.headers.get("accept")?.includes("text/html")) {
        return (await caches.match("/index.html")) || Response.error();
      }
      return Response.error();
    }
  })());
});
