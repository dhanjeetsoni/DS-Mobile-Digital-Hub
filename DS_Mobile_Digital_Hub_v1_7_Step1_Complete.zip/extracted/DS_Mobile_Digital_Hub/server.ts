import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.set("trust proxy", process.env.TRUST_PROXY === "true" ? 1 : false);
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";

app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(self), microphone=(), geolocation=()");
  next();
});
app.use(express.json({ limit: "15mb" }));

// Small in-memory limiter for expensive OCR calls. This is intentionally
// conservative; production deployments should also enforce edge/WAF limits.
const rateMap = new Map<string, { count: number; resetAt: number }>();
let lastRateMapSweep = 0;
function rateLimit(windowMs = 60_000, max = 12) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const now = Date.now();
    if (now - lastRateMapSweep > 60_000) {
      lastRateMapSweep = now;
      for (const [ip, entry] of rateMap) if (entry.resetAt <= now) rateMap.delete(ip);
    }
    const key = req.ip || "unknown";
    const current = rateMap.get(key);
    if (!current || current.resetAt <= now) {
      rateMap.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }
    current.count++;
    if (current.count > max) return res.status(429).json({ success: false, error: "Too many requests. Please try again shortly." });
    next();
  };
}

// ---------------------------------------------------------------------------
// Multi-key Gemini failover pool.
//
// Reads up to 5 keys from GEMINI_API_KEY_1..GEMINI_API_KEY_5 (falls back to
// the single GEMINI_API_KEY for key #1, so existing .env files keep working).
// Only ONE key is ever "active" at a time. If a call on the active key fails
// with a quota/rate-limit/auth error, the pool rotates to the next key and
// retries the same request — the caller never sees the failure unless every
// key is exhausted. A key that fails is put on a short cooldown so we don't
// keep hammering an exhausted key every request; it's retried again once the
// cooldown passes (quotas often reset daily/per-minute).
// ---------------------------------------------------------------------------
const GEMINI_KEYS: string[] = (() => {
  const keys: string[] = [];
  for (let i = 1; i <= 5; i++) {
    const k = process.env[`GEMINI_API_KEY_${i}`];
    if (k && k.trim()) keys.push(k.trim());
  }
  if (keys.length === 0 && process.env.GEMINI_API_KEY) {
    keys.push(process.env.GEMINI_API_KEY.trim());
  }
  return keys;
})();

const geminiClients = new Map<string, GoogleGenAI>();
function clientForKey(key: string): GoogleGenAI {
  let c = geminiClients.get(key);
  if (!c) {
    c = new GoogleGenAI({ apiKey: key, httpOptions: { headers: { "User-Agent": "ds-mobile-digital-hub" } } });
    geminiClients.set(key, c);
  }
  return c;
}

let activeKeyIndex = 0;
const keyCooldownUntil = new Map<number, number>(); // keyIndex -> timestamp ms

function isQuotaOrAuthError(err: any): boolean {
  const msg = String(err?.message || err || "").toLowerCase();
  const status = err?.status || err?.code;
  return (
    status === 429 ||
    status === 401 ||
    status === 403 ||
    msg.includes("429") ||
    msg.includes("quota") ||
    msg.includes("resource_exhausted") ||
    msg.includes("rate limit") ||
    msg.includes("permission_denied") ||
    msg.includes("unauthenticated") ||
    msg.includes("api key not valid")
  );
}

function hasAI(): boolean {
  return GEMINI_KEYS.length > 0;
}

// Runs `fn` against the currently active Gemini key. On a quota/auth failure
// it puts that key on a 60s cooldown and tries the next key in the ring,
// until either a key succeeds or every key has been tried once this call.
async function runWithGeminiFailover<T>(fn: (ai: GoogleGenAI) => Promise<T>): Promise<T> {
  if (GEMINI_KEYS.length === 0) throw new Error("AI unavailable");
  const now = Date.now();
  let lastError: any = null;
  for (let attempt = 0; attempt < GEMINI_KEYS.length; attempt++) {
    const idx = (activeKeyIndex + attempt) % GEMINI_KEYS.length;
    const cooldown = keyCooldownUntil.get(idx) || 0;
    if (cooldown > now && GEMINI_KEYS.length > 1) continue; // skip resting key, unless it's our only key
    try {
      const result = await fn(clientForKey(GEMINI_KEYS[idx]));
      activeKeyIndex = idx; // stick with the key that worked
      return result;
    } catch (err) {
      lastError = err;
      if (isQuotaOrAuthError(err)) {
        console.warn(`Gemini key #${idx + 1} failed (quota/auth) — rotating to next key.`);
        keyCooldownUntil.set(idx, now + 60_000);
        continue; // try next key
      }
      throw err; // non-quota error (bad request etc.) — no point retrying other keys
    }
  }
  throw lastError || new Error("All Gemini API keys exhausted");
}

const emptyResult = (imageType: string) => ({
  brand: "", modelName: "", imei1: "", imei2: "", serialNo: "", color: "",
  ramStorage: "", mrp: 0, sellingPriceSuggested: 0, androidVersion: "",
  batteryHealth: "", detectedCategory: imageType === "about_screen" ? "Second-Hand Mobile" : "New Mobile",
  notes: ""
});

function normalizeOcr(input: any, imageType: string) {
  const base = { ...emptyResult(imageType), ...(input || {}) };
  const cleanImei = (v: unknown) => {
    const digits = String(v || "").replace(/\D/g, "");
    return /^\d{15}$/.test(digits) ? digits : "";
  };
  return {
    ...base,
    brand: String(base.brand || "").trim(),
    modelName: String(base.modelName || "").trim(),
    imei1: cleanImei(base.imei1),
    imei2: cleanImei(base.imei2),
    serialNo: String(base.serialNo || "").trim(),
    color: String(base.color || "").trim(),
    ramStorage: String(base.ramStorage || "").trim(),
    mrp: Number(base.mrp) || 0,
    sellingPriceSuggested: Number(base.sellingPriceSuggested) || 0,
    androidVersion: String(base.androidVersion || "").trim(),
    batteryHealth: String(base.batteryHealth || "").trim(),
    detectedCategory: base.detectedCategory || emptyResult(imageType).detectedCategory,
    notes: String(base.notes || "").trim(),
  };
}

async function runGemini(base64Data: string, mimeType: string, imageType: string) {
  if (!hasAI()) return null;
  const prompt = `Read this mobile/product image. Extract ONLY information visibly supported by the image.
Return JSON fields: brand, modelName, imei1, imei2, serialNo, color, ramStorage, mrp, sellingPriceSuggested, androidVersion, batteryHealth, detectedCategory, notes.
Never invent or infer an absent value. An IMEI is valid only when a real 15-digit number is visibly present.
Image type: ${imageType}.`;
  const response = await runWithGeminiFailover((ai) =>
    ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-3.7-flash",
      contents: { parts: [{ inlineData: { data: base64Data, mimeType } }, { text: prompt }] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            brand:{type:Type.STRING}, modelName:{type:Type.STRING}, imei1:{type:Type.STRING},
            imei2:{type:Type.STRING}, serialNo:{type:Type.STRING}, color:{type:Type.STRING},
            ramStorage:{type:Type.STRING}, mrp:{type:Type.NUMBER}, sellingPriceSuggested:{type:Type.NUMBER},
            androidVersion:{type:Type.STRING}, batteryHealth:{type:Type.STRING},
            detectedCategory:{type:Type.STRING}, notes:{type:Type.STRING}
          }
        }
      }
    })
  );
  return normalizeOcr(JSON.parse(response.text || "{}"), imageType);
}

// Accessory packaging scanner: tempered glass / back cover / cable / etc.
// One physical item can be printed with dozens of compatible phone models
// (e.g. "For: R-ME7/C17/A32/A53 2020/..."). We extract the brand/product
// name ONCE and the full compatible-models list as a clean array, so the
// shop can save it as a SINGLE catalog item with one stock count that many
// models map onto — never one row per model.
function normalizeAccessory(input: any) {
  const base = input || {};
  const rawModels: unknown = base.compatibleModels;
  const models = Array.isArray(rawModels)
    ? rawModels.map((m) => String(m || "").trim()).filter(Boolean)
    : String(rawModels || "")
        .split(/[,/\n]/)
        .map((m) => m.trim())
        .filter(Boolean);
  // de-duplicate while preserving order
  const seen = new Set<string>();
  const compatibleModels = models.filter((m) => {
    const k = m.toLowerCase();
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return {
    brand: String(base.brand || "").trim(),
    productName: String(base.productName || "").trim(),
    category: String(base.category || "").trim() || "Accessories",
    compatibleModels,
    notes: String(base.notes || "").trim(),
    screenSizeInches: Number(base.screenSizeInches) || 0,
  };
}

async function runGeminiAccessory(base64Data: string, mimeType: string) {
  if (!hasAI()) return null;
  const prompt = `Read this accessory packaging photo (tempered glass, back cover, charger, cable, earphones etc. for mobile phones).
Extract ONLY information visibly printed/supported by the image. Return JSON fields:
- brand: the manufacturer/company name printed on the pack (e.g. "Super X"). Do NOT confuse this with a phone brand.
- productName: the short product title/tagline printed (e.g. "Edge to Edge Big Curved Glass", "ESD Anti-Static Tempered Glass").
- category: best single category, one of exactly: "Tempered Glass", "Back Covers", "Charger", "Cable", "Earphones", "Accessories".
- compatibleModels: an array of EVERY individual phone model this item fits, taken from any "For:" / compatibility list on the pack.
  Expand abbreviations into readable model names (e.g. "R-ME7" -> "Realme 7", "R-ME C17" -> "Realme C17", "1+NORD N100" -> "OnePlus Nord N100").
  Split combined lists like "A32/A33 2020/A53 2020" into separate array entries, keeping the shared brand prefix inferred from context (e.g. Samsung A32, Samsung A33 2020, Samsung A53 2020).
  Include every model listed, do not truncate or summarize the list.
- notes: any other relevant printed detail (finish, protection type) in a short phrase, or empty string.
- screenSizeInches: if the pack prints a screen-size compatibility (e.g. "For 6.5-6.7 inch mobiles"), return the largest number in that range as a decimal. If no screen size is printed, return 0.
Never invent a model that is not printed on the pack.`;
  const response = await runWithGeminiFailover((ai) =>
    ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-3.7-flash",
      contents: { parts: [{ inlineData: { data: base64Data, mimeType } }, { text: prompt }] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            brand: { type: Type.STRING },
            productName: { type: Type.STRING },
            category: { type: Type.STRING },
            compatibleModels: { type: Type.ARRAY, items: { type: Type.STRING } },
            notes: { type: Type.STRING },
            screenSizeInches: { type: Type.NUMBER },
          }
        }
      }
    })
  );
  return normalizeAccessory(JSON.parse(response.text || "{}"));
}

// ---------------------------------------------------------------------------
// Screen-size lookup: given a phone model name the shop doesn't have listed
// under any glass/cover's compatibleModels, ask Gemini for that phone's
// screen size so it can still be matched against accessories that recorded
// a screenSizeInches. Small in-memory cache since the same models get asked
// repeatedly across a day.
// ---------------------------------------------------------------------------
const screenSizeCache = new Map<string, { size: number; at: number }>();
const SCREEN_SIZE_CACHE_MS = 24 * 60 * 60 * 1000;

async function runScreenSizeLookup(modelName: string): Promise<number> {
  const key = modelName.trim().toLowerCase();
  const cached = screenSizeCache.get(key);
  if (cached && Date.now() - cached.at < SCREEN_SIZE_CACHE_MS) return cached.size;
  if (!hasAI()) return 0;
  const prompt = `What is the diagonal screen size, in inches, of the mobile phone "${modelName}"?
Reply with ONLY the number rounded to 1 decimal place (e.g. "6.7"). If you are not confident which phone this is, reply "0".`;
  const response = await runWithGeminiFailover((ai) =>
    ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-3.7-flash",
      contents: { parts: [{ text: prompt }] },
    })
  );
  const size = parseFloat(String(response.text || "0").trim().match(/[\d.]+/)?.[0] || "0") || 0;
  screenSizeCache.set(key, { size, at: Date.now() });
  return size;
}

// ---------------------------------------------------------------------------
// Staff "Photo Stock Finder": staff snaps a photo of ANY item in the shop
// (a phone, a charger, a cover on the rack, a box, an earphone pack) and the
// AI identifies what it is + gives short search keywords. The client then
// searches the shop's OWN catalog (never invented items) by those keywords
// and lets staff add a matching in-stock item straight to the bill. This is
// a search-keyword generator only — it never returns price/stock, since
// those must always come from the shop's real database, not the AI.
// ---------------------------------------------------------------------------
function normalizeProductPhoto(input: any) {
  const base = input || {};
  const keywords = Array.isArray(base.searchKeywords)
    ? base.searchKeywords.map((k: unknown) => String(k || "").trim()).filter(Boolean).slice(0, 8)
    : [];
  return {
    itemType: String(base.itemType || "").trim(),
    brand: String(base.brand || "").trim(),
    productName: String(base.productName || "").trim(),
    color: String(base.color || "").trim(),
    searchKeywords: keywords,
    notes: String(base.notes || "").trim(),
  };
}

async function runGeminiProductPhoto(base64Data: string, mimeType: string) {
  if (!hasAI()) return null;
  const prompt = `Look at this photo of a product/item from a mobile phone & digital accessories shop
(could be a phone, a tempered glass, a back cover, a charger, a cable, earphones, a power bank, or any
other shop item, on a shelf, in a hand, or in its box). Identify ONLY what is visibly supported by the
image. Return JSON fields:
- itemType: short category guess, e.g. "Mobile Phone", "Tempered Glass", "Back Cover", "Charger", "Cable", "Earphones", "Power Bank", "Accessory".
- brand: manufacturer/brand name visible on the item or packaging, or empty string if not visible.
- productName: short product name/title visible, or your best short visible description (e.g. "Black silicone back cover"), or empty string.
- color: dominant visible color, or empty string.
- searchKeywords: an array of 3-6 short keywords (brand names, model numbers, product type, color) a shop
  search box could use to find this exact item in an existing catalog. Do NOT invent a model number that
  isn't visible — only include keywords actually supported by the image.
- notes: any other short useful visible detail, or empty string.
Never invent details not visible in the photo.`;
  const response = await runWithGeminiFailover((ai) =>
    ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-3.7-flash",
      contents: { parts: [{ inlineData: { data: base64Data, mimeType } }, { text: prompt }] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            itemType: { type: Type.STRING },
            brand: { type: Type.STRING },
            productName: { type: Type.STRING },
            color: { type: Type.STRING },
            searchKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            notes: { type: Type.STRING },
          },
        },
      },
    })
  );
  return normalizeProductPhoto(JSON.parse(response.text || "{}"));
}

// ---------------------------------------------------------------------------
// Staff-mode quick advice: a short, actionable Hinglish tip aimed at a staff
// member on shift (not the owner) — what to focus on right now to help
// sales, using only the small non-sensitive numeric snapshot the client
// sends (today's sales so far, top-moving items, low-stock items). Kept
// separate from /api/business-insights (owner-only, full P&L) so staff never
// receive profit/margin/expense figures.
// ---------------------------------------------------------------------------
async function runStaffAdvice(summary: Record<string, unknown>): Promise<string> {
  if (!hasAI()) throw new Error("AI unavailable");
  const prompt = `You are a friendly shift-advisor for a staff member working the counter at a small Indian
mobile phone & digital services shop today. Using ONLY the numbers given below, write short, practical,
encouraging tips in simple Hinglish (Hindi+English mix, easy to read fast between customers). Use short
bullet points (use "-" per line, no markdown headers, no bold/asterisks). Cover:
1) Aaj ab tak kaisa chal raha hai — 1 line, encouraging tone.
2) Kaunsa item push/upsell karna chahiye abhi (fast-moving ya combo-worthy items) — 1-2 lines, name items if given.
3) Kaunsa low-stock item hai jiske liye customer ko turant batana/order lena chahiye — 1 line if any given.
4) Ek chhota customer-service tip for today.
Do NOT mention profit, margin, cost price, or expenses — staff should not see those. Keep the whole reply
under 120 words. Do not invent numbers not present below.

DATA:
${JSON.stringify(summary)}`;
  const response = await runWithGeminiFailover((ai) =>
    ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-3.7-flash",
      contents: { parts: [{ text: prompt }] },
    })
  );
  return (response.text || "").trim();
}

async function runBusinessInsights(summary: Record<string, unknown>): Promise<string> {
  if (!hasAI()) throw new Error("AI unavailable");
  const prompt = `You are a business advisor for a small Indian mobile phone & digital services shop.
All amounts are in INR (₹). Based ONLY on the numbers given below, write a short, practical business
summary in simple Hinglish (Hindi+English mix, easy for a shopkeeper to read). Cover, in short bullet
points (use "-" per line, no markdown headers, no bold/asterisks):
1) Is month ka overall hisaab (sales, expenses, profit) — 1-2 lines.
2) Byaj/loan interest aur muldhan repayment ke liye kitna paisa alag rakhna chahiye (savings target) — 1-2 lines.
3) Kaunsa saman jyada bik raha hai aur kya order/reorder karna chahiye — 1-2 lines, name specific items if given.
4) Ek clear warning ya suggestion agar kharcha zyada ho raha ho ya due/baaki zyada ho.
Keep the whole reply under 160 words. Do not invent numbers not present below.

DATA:
${JSON.stringify(summary)}`;
  const response = await runWithGeminiFailover((ai) =>
    ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-3.7-flash",
      contents: { parts: [{ text: prompt }] },
    })
  );
  return (response.text || "").trim();
}

// IMEI is validated by the strict 15-digit regex in normalizeOcr() and by
// the "requiresVerification" flag the client already forces the staff to
// confirm — that is the verification step now that there is no second
// (OCR.space) provider to cross-check against.

async function requireSupabaseUser(req: express.Request, res: express.Response) {
  const auth = req.header("authorization") || "";
  const token = auth.replace(/^Bearer\s+/i, "").trim();
  const url = process.env.SUPABASE_URL || "";
  const key = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || "";
  if (!token || !url || !key) {
    res.status(401).json({ success: false, error: "Authentication required." });
    return null;
  }
  const client = createClient(url, key, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data, error } = await client.auth.getUser(token);
  if (error || !data.user) {
    res.status(401).json({ success: false, error: "Invalid or expired session." });
    return null;
  }
  return data.user;
}

app.get("/api/health", (_req, res) => {
  // Do not expose secret/configuration presence to unauthenticated callers.
  res.json({ status: "ok", environment: process.env.NODE_ENV || "development" });
});

app.post("/api/ocr-phone", rateLimit(), async (req, res) => {
  const user = await requireSupabaseUser(req, res);
  if (!user) return;
  try {
    const { image, imageType = "auto" } = req.body || {};
    if (!image || typeof image !== "string") return res.status(400).json({ success: false, error: "No image provided." });
    if (image.length > 14_000_000) return res.status(413).json({ success: false, error: "Image is too large." });

    let mimeType = "image/jpeg";
    let base64Data = image;
    if (image.startsWith("data:")) {
      const parts = image.split(";base64,");
      mimeType = parts[0].replace("data:", "") || mimeType;
      base64Data = parts[1] || "";
    }
    if (!/^image\/(jpeg|png|webp|jpg)$/i.test(mimeType)) return res.status(415).json({ success: false, error: "Unsupported image type." });

    const gemini = await runGemini(base64Data, mimeType, imageType);

    if (gemini) {
      const data = normalizeOcr(gemini, imageType);
      // A staff member must still eyeball the IMEI/serial before saving —
      // that manual glance is the verification step (no second AI/OCR
      // provider to auto cross-check against anymore).
      return res.json({
        success: true,
        provider: "gemini",
        verified: false,
        requiresVerification: true,
        mismatches: [],
        rawText: "",
        data,
      });
    }

    return res.status(503).json({ success: false, error: "AI unavailable — enter manually." });
  } catch (error) {
    console.error("OCR endpoint error", error);
    res.status(500).json({ success: false, error: "OCR service failed. Enter manually." });
  }
});

app.post("/api/ocr-accessory", rateLimit(), async (req, res) => {
  const user = await requireSupabaseUser(req, res);
  if (!user) return;
  try {
    const { image } = req.body || {};
    if (!image || typeof image !== "string") return res.status(400).json({ success: false, error: "No image provided." });
    if (image.length > 14_000_000) return res.status(413).json({ success: false, error: "Image is too large." });

    let mimeType = "image/jpeg";
    let base64Data = image;
    if (image.startsWith("data:")) {
      const parts = image.split(";base64,");
      mimeType = parts[0].replace("data:", "") || mimeType;
      base64Data = parts[1] || "";
    }
    if (!/^image\/(jpeg|png|webp|jpg)$/i.test(mimeType)) return res.status(415).json({ success: false, error: "Unsupported image type." });

    const data = await runGeminiAccessory(base64Data, mimeType);
    if (!data) return res.status(503).json({ success: false, error: "AI unavailable — enter manually." });
    return res.json({ success: true, provider: "gemini", data });
  } catch (error) {
    console.error("Accessory OCR endpoint error", error);
    res.status(500).json({ success: false, error: "AI scan failed. Enter manually." });
  }
});

app.post("/api/screen-size-lookup", rateLimit(60_000, 30), async (req, res) => {
  const user = await requireSupabaseUser(req, res);
  if (!user) return;
  try {
    const { modelName } = req.body || {};
    if (!modelName || typeof modelName !== "string" || modelName.trim().length < 2) {
      return res.status(400).json({ success: false, error: "No model name provided." });
    }
    const size = await runScreenSizeLookup(modelName.trim().slice(0, 80));
    if (!size) return res.status(503).json({ success: false, error: "Could not determine screen size for this model." });
    return res.json({ success: true, modelName: modelName.trim(), screenSizeInches: size });
  } catch (error) {
    console.error("Screen-size lookup error", error);
    res.status(500).json({ success: false, error: "Lookup failed." });
  }
});

app.post("/api/business-insights", rateLimit(60_000, 6), async (req, res) => {
  const user = await requireSupabaseUser(req, res);
  if (!user) return;
  try {
    const summary = req.body?.summary;
    if (!summary || typeof summary !== "object") {
      return res.status(400).json({ success: false, error: "No summary data provided." });
    }
    const insights = await runBusinessInsights(summary);
    if (!insights) return res.status(503).json({ success: false, error: "AI unavailable — try again shortly." });
    return res.json({ success: true, insights });
  } catch (error) {
    console.error("Business insights endpoint error", error);
    res.status(500).json({ success: false, error: "AI insights failed. Try again shortly." });
  }
});

app.post("/api/staff-advice", rateLimit(60_000, 10), async (req, res) => {
  const user = await requireSupabaseUser(req, res);
  if (!user) return;
  try {
    const summary = req.body?.summary;
    if (!summary || typeof summary !== "object") {
      return res.status(400).json({ success: false, error: "No summary data provided." });
    }
    const advice = await runStaffAdvice(summary);
    if (!advice) return res.status(503).json({ success: false, error: "AI unavailable — try again shortly." });
    return res.json({ success: true, advice });
  } catch (error) {
    console.error("Staff advice endpoint error", error);
    res.status(500).json({ success: false, error: "AI advice failed. Try again shortly." });
  }
});

app.post("/api/product-photo-search", rateLimit(), async (req, res) => {
  const user = await requireSupabaseUser(req, res);
  if (!user) return;
  try {
    const { image } = req.body || {};
    if (!image || typeof image !== "string") return res.status(400).json({ success: false, error: "No image provided." });
    if (image.length > 14_000_000) return res.status(413).json({ success: false, error: "Image is too large." });

    let mimeType = "image/jpeg";
    let base64Data = image;
    if (image.startsWith("data:")) {
      const parts = image.split(";base64,");
      mimeType = parts[0].replace("data:", "") || mimeType;
      base64Data = parts[1] || "";
    }
    if (!/^image\/(jpeg|png|webp|jpg)$/i.test(mimeType)) return res.status(415).json({ success: false, error: "Unsupported image type." });

    const data = await runGeminiProductPhoto(base64Data, mimeType);
    if (!data) return res.status(503).json({ success: false, error: "AI unavailable — search manually." });
    return res.json({ success: true, provider: "gemini", data });
  } catch (error) {
    console.error("Product photo search endpoint error", error);
    res.status(500).json({ success: false, error: "AI photo search failed. Search manually." });
  }
});

async function start() {
  if (!isProduction) {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const dist = path.resolve(__dirname, "dist");
    app.use(express.static(dist, { maxAge: "1y", index: false }));
    app.get("*", (_req, res) => res.sendFile(path.join(dist, "index.html")));
  }

  app.use((error: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error("Unhandled server error", error);
    if (!res.headersSent) res.status(500).json({ error: "Internal server error." });
  });

  app.listen(PORT, () => console.log(`DS Mobile & Digital Hub running on http://localhost:${PORT}`));
}

start().catch((error) => {
  console.error("Server startup failed", error);
  process.exit(1);
});
