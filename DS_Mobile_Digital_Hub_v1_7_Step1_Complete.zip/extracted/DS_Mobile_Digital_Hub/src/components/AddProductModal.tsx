import React, { useRef, useState } from "react";
import { Sparkles, Upload, CheckCircle2, AlertCircle, X, Plus, RefreshCw, Barcode, ShieldCheck } from "lucide-react";
import { Database, Product } from "../types";
import { uid, genSku, genBarcode } from "../utils/fifoEngine";
import { processAccessoryOcr } from "../utils/aiOcr";
import { compressImageToDataUrl } from "../utils/imageCompress";
import { uploadProductPhotoOrFallback } from "../services/photoStorage";

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  db: Database;
  storeId?: string;
  onCreated: (product: Product) => void;
  toast: (msg: string, type?: "green" | "red" | "amber") => void;
}

const BUILTIN_CATEGORY_OPTIONS = [
  "Tempered Glass",
  "Back Covers",
  "Charger",
  "Cable",
  "Earphones",
  "Accessories",
  "Spare Parts",
  "General",
];

export const AddProductModal: React.FC<AddProductModalProps> = ({
  isOpen,
  onClose,
  db,
  storeId,
  onCreated,
  toast,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  // Stable per-modal-session id used only as the Storage path segment for
  // this photo — independent of the product's own id (generated at Save
  // time) so the upload can start the moment a photo is picked.
  const photoPathIdRef = useRef<string>(uid("tmp"));

  const [photo, setPhoto] = useState<string>("");
  // True once `photo` holds a real Storage URL rather than a data: URL
  // fallback. Purely informational (small hint in the UI); Save works
  // either way.
  const [photoIsUploaded, setPhotoIsUploaded] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanError, setScanError] = useState("");
  const [aiApplied, setAiApplied] = useState(false);

  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [category, setCategory] = useState("Tempered Glass");
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategoryInput, setNewCategoryInput] = useState("");
  const [compatibleModels, setCompatibleModels] = useState<string[]>([]);
  const [modelInput, setModelInput] = useState("");
  const [screenSizeInches, setScreenSizeInches] = useState<number>(0);
  const [notes, setNotes] = useState("");
  const isScreenAccessory = category === "Tempered Glass" || category === "Back Covers";

  // These are always left blank for the shop to fill in — never guessed by AI.
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [stock, setStock] = useState<number>(0);
  const [minStock, setMinStock] = useState<number>(2);
  const [supplier, setSupplier] = useState("");

  // Barcode: generated once here and saved on the product. Any future
  // camera/handheld scan of this exact code will auto-fill this product
  // into the POS cart with its current selling price.
  const [barcode, setBarcode] = useState<string>("");

  // Warranty: when enabled, checkout will require the customer's name &
  // phone for this product. When disabled, customer details stay optional.
  const [warrantyEnabled, setWarrantyEnabled] = useState<boolean>(false);
  const [warrantyMonths, setWarrantyMonths] = useState<number>(6);
  const [requireCustomerDetails, setRequireCustomerDetails] = useState<boolean>(false);

  if (!isOpen) return null;

  const resetForm = () => {
    setPhoto("");
    setPhotoIsUploaded(false);
    photoPathIdRef.current = uid("tmp");
    setScanError("");
    setAiApplied(false);
    setName("");
    setBrand("");
    setCategory("Tempered Glass");
    setCompatibleModels([]);
    setModelInput("");
    setScreenSizeInches(0);
    setNotes("");
    setPurchasePrice(0);
    setSellingPrice(0);
    setStock(0);
    setMinStock(2);
    setSupplier("");
    setIsAddingCategory(false);
    setNewCategoryInput("");
    setBarcode("");
    setWarrantyEnabled(false);
    setWarrantyMonths(6);
    setRequireCustomerDetails(false);
  };

  const handleGenerateBarcode = () => {
    const code = genBarcode();
    setBarcode(code);
    toast(`Barcode generated: ${code} — Save karne par ye product ke saath save ho jayega`, "green");
  };

  // Owner-added categories (db.categories) merged with the built-in list, so
  // once a shop adds "Powerbanks" or "Smart Watches" it shows up here every
  // time — not just for that one save.
  const categoryOptions = Array.from(
    new Set([...BUILTIN_CATEGORY_OPTIONS, ...(db.categories || [])])
  );

  const commitNewCategory = () => {
    const cleaned = newCategoryInput.trim();
    if (!cleaned) { setIsAddingCategory(false); return; }
    if (!db.categories) db.categories = [];
    if (!db.categories.some((c) => c.toLowerCase() === cleaned.toLowerCase())) {
      db.categories.push(cleaned);
    }
    setCategory(cleaned);
    setIsAddingCategory(false);
    setNewCategoryInput("");
    toast(`"${cleaned}" category add ho gayi`, "green");
  };

  const handleImageSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Compress once here — this same small JPEG is what goes to the AI
    // scanner. The permanent product photo is now uploaded to Supabase
    // Storage in parallel (see uploadProductPhotoOrFallback below) so the
    // synced JSON state only ever holds a short URL, not the image bytes —
    // if that upload fails (offline, cloud not configured) it falls back
    // to the old data: URL behaviour automatically, so nothing breaks.
    try {
      const dataUrl = await compressImageToDataUrl(file);
      setPhoto(dataUrl); // optimistic preview while upload runs
      const uploadPromise = uploadProductPhotoOrFallback(storeId, photoPathIdRef.current, file)
        .then(({ url, uploaded }) => {
          setPhoto(url);
          setPhotoIsUploaded(uploaded);
        })
        .catch(() => {});
      await runScan(dataUrl);
      await uploadPromise;
    } catch (err: any) {
      toast(err?.message || "Photo process nahi ho payi, dobara try karein", "red");
    }
  };

  const runScan = async (imgData: string) => {
    setIsScanning(true);
    setScanError("");
    try {
      const result = await processAccessoryOcr(imgData);
      if (result.brand) setBrand(result.brand);
      if (result.category) setCategory(result.category);
      if (result.brand || result.productName) {
        setName([result.brand, result.productName].filter(Boolean).join(" — "));
      }
      if (result.compatibleModels?.length) setCompatibleModels(result.compatibleModels);
      if (result.screenSizeInches) setScreenSizeInches(result.screenSizeInches);
      if (result.notes) setNotes(result.notes);
      setAiApplied(true);
      toast(
        result.compatibleModels?.length
          ? `AI ne ${result.compatibleModels.length} models detect kiye — check karke Save karein`
          : "AI ne photo padh li, models nahi mile — neeche manually add karein",
        result.compatibleModels?.length ? "green" : "amber"
      );
    } catch (err: any) {
      setScanError(err.message || "AI scan fail ho gaya. Details manually bharein.");
    } finally {
      setIsScanning(false);
    }
  };

  const addModelFromInput = () => {
    const raw = modelInput.trim();
    if (!raw) return;
    // allow pasting/typing several models separated by comma or slash at once
    const parts = raw.split(/[,/]/).map((m) => m.trim()).filter(Boolean);
    const merged = [...compatibleModels];
    for (const part of parts) {
      if (!merged.some((m) => m.toLowerCase() === part.toLowerCase())) merged.push(part);
    }
    setCompatibleModels(merged);
    setModelInput("");
  };

  const removeModel = (m: string) => {
    setCompatibleModels(compatibleModels.filter((x) => x !== m));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast("Product name required", "red");
      return;
    }
    if (sellingPrice <= 0) {
      toast("Selling price required", "red");
      return;
    }
    if (barcode.trim() && db.products.some((p) => p.barcode === barcode.trim())) {
      toast("Ye barcode already kisi doosre product mein use ho raha hai. Naya generate karein.", "red");
      return;
    }

    // ONE catalog item, no matter how many models it fits — stock, price
    // and SKU all live on this single record. Model search just filters
    // by compatibleModels; it never creates a separate row per model.
    const product: Product = {
      id: uid("p"),
      name: name.trim(),
      category,
      brand: brand.trim(),
      sku: genSku(category === "Tempered Glass" ? "GLS" : category === "Back Covers" ? "CVR" : "ACC"),
      barcode: barcode.trim() || undefined,
      photo,
      purchasePrice: purchasePrice || null,
      pendingCost: !purchasePrice,
      sellingPrice,
      stock,
      minStock,
      warrantyEnabled,
      warrantyMonths: warrantyEnabled ? warrantyMonths : 0,
      requireCustomerDetails: warrantyEnabled ? true : requireCustomerDetails,
      supplier: supplier.trim(),
      notes: notes.trim(),
      compatibleModels,
      screenSizeInches: isScreenAccessory && screenSizeInches ? screenSizeInches : undefined,
      createdAt: new Date().toISOString(),
    };

    db.products.push(product);
    onCreated(product);
    toast(`${product.name} added — ${compatibleModels.length || 0} model(s) linked, stock ${stock}`, "green");
    resetForm();
    onClose();
  };

  return (
    <div className="overlay show">
      <div className="modal wide">
        <div className="modal-head">
          <h3>
            <Sparkles size={18} style={{ color: "var(--glow)", marginRight: "8px", verticalAlign: "middle" }} />
            Add New Product / Item (Glass, Cover, Charger, etc.)
          </h3>
          <button onClick={() => { resetForm(); onClose(); }}>&times;</button>
        </div>

        <div className="grid cols-2" style={{ alignItems: "flex-start", gap: "18px" }}>
          {/* Left: photo + AI scan */}
          <div>
            <div
              style={{
                border: "2px dashed var(--line)",
                borderRadius: "12px",
                padding: "16px",
                textAlign: "center",
                background: "var(--card)",
                cursor: "pointer",
              }}
              onClick={() => fileInputRef.current?.click()}
            >
              {photo ? (
                <img src={photo} alt="Product" style={{ width: "100%", maxHeight: "260px", objectFit: "contain", borderRadius: "8px" }} />
              ) : (
                <div style={{ padding: "26px 10px" }}>
                  <Upload size={34} style={{ color: "var(--ink-soft)", marginBottom: "8px" }} />
                  <div style={{ fontWeight: 700, fontSize: "14px" }}>Packaging ka photo lagayein</div>
                  <div className="hint">AI brand, product name, category aur sab compatible models khud padh lega</div>
                  <div className="hint" style={{ marginTop: "4px" }}>Ye photo compress hoke product ke saath hamesha save rahegi — sab staff ko dikhegi</div>
                  <button type="button" className="btn primary sm" style={{ marginTop: "12px" }}>
                    <Upload size={14} /> Select / Capture Photo
                  </button>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                style={{ display: "none" }}
                onChange={handleImageSelected}
              />
            </div>

            {photo && !isScanning && (
              <button type="button" className="btn sm" style={{ width: "100%", marginTop: "10px" }} onClick={() => runScan(photo)}>
                <RefreshCw size={13} /> Re-scan with AI
              </button>
            )}

            {isScanning && (
              <div style={{ textAlign: "center", padding: "20px 10px" }}>
                <Sparkles size={26} style={{ color: "var(--glow)", animation: "spinCheck 1s linear infinite" }} />
                <div style={{ fontWeight: 700, marginTop: "8px", fontSize: "13px" }}>AI photo padh raha hai...</div>
              </div>
            )}

            {scanError && (
              <div className="alert red" style={{ marginTop: "10px" }}>
                <AlertCircle size={16} />
                <span>{scanError}</span>
              </div>
            )}

            {aiApplied && !isScanning && (
              <div className="alert" style={{ marginTop: "10px", background: "var(--green-light)", color: "var(--green)" }}>
                <CheckCircle2 size={16} />
                <span>AI ne form fill kar diya hai — neeche check karke price/stock daalein.</span>
              </div>
            )}
          </div>

          {/* Right: form */}
          <form onSubmit={handleSave}>
            <div className="formgrid">
              <div className="field full">
                <label>Product Name <span className="req">*</span></label>
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Super X Edge to Edge Tempered Glass" required />
              </div>

              <div className="field">
                <label>Brand / Company</label>
                <input value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="e.g. Super X" />
              </div>

              <div className="field">
                <label>Category</label>
                {!isAddingCategory ? (
                  <div style={{ display: "flex", gap: "6px" }}>
                    <select value={category} onChange={(e) => setCategory(e.target.value)} style={{ flex: 1 }}>
                      {categoryOptions.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                    <button
                      type="button"
                      className="btn sm"
                      title="Naya category naam khud add karein"
                      onClick={() => setIsAddingCategory(true)}
                    >
                      <Plus size={13} /> Naya
                    </button>
                  </div>
                ) : (
                  <div style={{ display: "flex", gap: "6px" }}>
                    <input
                      autoFocus
                      value={newCategoryInput}
                      onChange={(e) => setNewCategoryInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") { e.preventDefault(); commitNewCategory(); }
                        if (e.key === "Escape") { setIsAddingCategory(false); setNewCategoryInput(""); }
                      }}
                      placeholder="e.g. Powerbanks, Smart Watches"
                      style={{ flex: 1 }}
                    />
                    <button type="button" className="btn sm primary" onClick={commitNewCategory}>Add</button>
                    <button type="button" className="btn sm" onClick={() => { setIsAddingCategory(false); setNewCategoryInput(""); }}>&times;</button>
                  </div>
                )}
              </div>

              {isScreenAccessory && (
                <div className="field full" style={{ background: "var(--paper)", padding: "10px 12px", borderRadius: "8px" }}>
                  <label>Compatible Phone Models ({compatibleModels.length})</label>
                  <div style={{ display: "flex", gap: "8px" }}>
                    <input
                      value={modelInput}
                      onChange={(e) => setModelInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") { e.preventDefault(); addModelFromInput(); }
                      }}
                      placeholder="Type a model and press Enter — ya comma se kai models ek saath paste karein"
                    />
                    <button type="button" className="btn sm" onClick={addModelFromInput}>
                      <Plus size={13} /> Add
                    </button>
                  </div>
                  {compatibleModels.length > 0 && (
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginTop: "8px" }}>
                      {compatibleModels.map((m) => (
                        <span
                          key={m}
                          style={{
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "4px",
                            fontSize: "11.5px",
                            fontWeight: 600,
                            background: "var(--card)",
                            border: "1px solid var(--line)",
                            borderRadius: "999px",
                            padding: "3px 8px 3px 10px",
                          }}
                        >
                          {m}
                          <X size={12} style={{ cursor: "pointer" }} onClick={() => removeModel(m)} />
                        </span>
                      ))}
                    </div>
                  )}

                  <div style={{ marginTop: "10px" }}>
                    <label>Screen Size (inches) — optional, for AI matching</label>
                    <input
                      type="number" min="0" step="0.1"
                      value={screenSizeInches || ""}
                      onChange={(e) => setScreenSizeInches(Number(e.target.value) || 0)}
                      placeholder="e.g. 6.7"
                      style={{ maxWidth: "140px" }}
                    />
                    <div className="hint" style={{ marginTop: "4px" }}>
                      Model list mein na milne par bhi, isi screen size ke doosre phones staff ko search mein AI se dikh jayenge.
                    </div>
                  </div>

                  <div className="hint" style={{ marginTop: "6px" }}>
                    Ye ek hi item hai, chahe jitne models fit ho — stock aur price sirf ek baar niche bharna hai.
                  </div>
                </div>
              )}

              <div className="field">
                <label>Stock Quantity <span className="req">*</span></label>
                <input type="number" min="0" value={stock} onChange={(e) => setStock(Number(e.target.value) || 0)} required />
              </div>

              <div className="field">
                <label>Low-Stock Alert Below</label>
                <input type="number" min="0" value={minStock} onChange={(e) => setMinStock(Number(e.target.value) || 0)} />
              </div>

              <div className="field">
                <label>Purchase / Cost Price (₹)</label>
                <input type="number" min="0" step="0.01" value={purchasePrice || ""} onChange={(e) => setPurchasePrice(Number(e.target.value) || 0)} placeholder="0" />
              </div>

              <div className="field">
                <label>Selling Price (₹) <span className="req">*</span></label>
                <input type="number" min="0" step="0.01" value={sellingPrice || ""} onChange={(e) => setSellingPrice(Number(e.target.value) || 0)} placeholder="0" required />
              </div>

              <div className="field">
                <label>Supplier / Distributor</label>
                <input value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="e.g. Anand Telecom" />
              </div>

              <div className="field">
                <label>Rack / Location Notes</label>
                <input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="e.g. Rack B, Box 3" />
              </div>

              <div className="field full" style={{ background: "var(--paper)", padding: "10px 12px", borderRadius: "8px" }}>
                <label><Barcode size={13} style={{ verticalAlign: "middle", marginRight: "4px" }} /> Barcode</label>
                <div style={{ display: "flex", gap: "8px" }}>
                  <input
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value.replace(/\s/g, ""))}
                    placeholder="Generate karein ya khud type/scan karein"
                    style={{ flex: 1, fontFamily: "var(--font-mono)" }}
                  />
                  <button type="button" className="btn sm primary" onClick={handleGenerateBarcode}>
                    <Barcode size={13} /> Generate Barcode
                  </button>
                </div>
                <div className="hint" style={{ marginTop: "4px" }}>
                  Save karne ke baad, is barcode ko future mein scan karte hi ye product, uska price aur details automatically POS cart mein aa jayenge.
                </div>
              </div>

              <div className="field full" style={{ background: "var(--paper)", padding: "10px 12px", borderRadius: "8px" }}>
                <label><ShieldCheck size={13} style={{ verticalAlign: "middle", marginRight: "4px" }} /> Warranty</label>
                <label style={{ display: "flex", alignItems: "center", gap: "8px", fontWeight: 600, fontSize: "13px" }}>
                  <input type="checkbox" checked={warrantyEnabled} onChange={(e) => setWarrantyEnabled(e.target.checked)} />
                  Is product par warranty hai
                </label>
                {warrantyEnabled ? (
                  <>
                    <div style={{ marginTop: "8px" }}>
                      <label>Warranty Duration (months)</label>
                      <input type="number" min="1" value={warrantyMonths} onChange={(e) => setWarrantyMonths(Number(e.target.value) || 1)} style={{ maxWidth: "140px" }} />
                    </div>
                    <div className="hint" style={{ marginTop: "6px" }}>
                      Warranty hone par, sell karte waqt customer ka naam aur phone number lena zaroori hoga.
                    </div>
                  </>
                ) : (
                  <>
                    <label style={{ display: "flex", alignItems: "center", gap: "8px", fontWeight: 600, fontSize: "13px", marginTop: "8px" }}>
                      <input type="checkbox" checked={requireCustomerDetails} onChange={(e) => setRequireCustomerDetails(e.target.checked)} />
                      Customer details phir bhi zaroori rakhein (optional)
                    </label>
                    <div className="hint" style={{ marginTop: "4px" }}>
                      Warranty nahi hai — customer details by default optional rahenge, jab tak upar wala checkbox tick na karein.
                    </div>
                  </>
                )}
              </div>
            </div>

            <div className="modal-actions" style={{ marginTop: "16px" }}>
              <button type="button" className="btn" onClick={() => { resetForm(); onClose(); }}>Cancel</button>
              <button type="submit" className="btn primary">
                <CheckCircle2 size={16} /> Save Product to Catalog
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
