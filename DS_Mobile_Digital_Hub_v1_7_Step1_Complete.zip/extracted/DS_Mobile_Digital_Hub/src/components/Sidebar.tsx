import React, { useState } from "react";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Wrench,
  Search,
  Receipt,
  FileText,
  RotateCcw,
  BookOpen,
  Tag,
  Calendar,
  TrendingUp,
  DollarSign,
  User,
  Shield,
  Save,
  Settings as SettingsIcon,
  Smartphone,
  Layers,
  Radio,
  Landmark,
  CreditCard,
  Camera,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Monitor,
  Percent,
  Users,
} from "lucide-react";
import { Database } from "../types";
import { inr } from "../utils/indianCurrency";
import { todayStr } from "../utils/fifoEngine";

interface SidebarProps {
  db: Database;
  currentPage: string;
  onNavigate: (page: string) => void;
  ownerMode: boolean;
  onToggleOwnerMode: () => void;
  onThemeChange: (theme: string) => void;
  onOpenQuickScan: () => void;
  onOpenWindowsModal?: () => void;
}

// 6 Core Daily Counter Items for Ultra-Easy Counter Work
export const PRIMARY_NAV_ITEMS = [
  { key: "dashboard", label: "Dashboard ()", icon: LayoutDashboard },
  { key: "sell", label: "Sales / New Bill", icon: ShoppingCart },
  { key: "imeiTracker", label: "Mobile & IMEI", icon: Smartphone },
  { key: "xeroxGrid", label: "Xerox / Cyber 1-Tap ()", icon: Layers },
  { key: "gallaClosing", label: "Daily Galla", icon: DollarSign },
  { key: "jobs", label: "Repairs & Service ()", icon: Wrench },
  { key: "khata", label: "Customer Khata", icon: CreditCard },
  { key: "modelsearch", label: "Glass & Cover", icon: Search },
  { key: "photoFinder", label: "Photo Stock Finder", icon: Camera },
];

// Advanced & Secondary Tools
export const SECONDARY_NAV_ITEMS = [
  { key: "products", label: "All Products", icon: Package, ownerOnly: false },
  { key: "customerDirectory", label: "Customer Directory", icon: Users, ownerOnly: true },
  { key: "secondHandKyc", label: "2nd-Hand Buyback KYC", icon: Shield, ownerOnly: true },
  { key: "simTracker", label: "SIM & Lapu Wallet", icon: Radio, ownerOnly: false },
  { key: "financeLedger", label: "Mobile Finance (Bajaj/TVS)", icon: Landmark, ownerOnly: false },
  { key: "supplierKhata", label: "Supplier / DLR Khata", icon: BookOpen, ownerOnly: true },
  { key: "labels", label: "Barcode & Price Tags", icon: Tag, ownerOnly: false },
  { key: "invoices", label: "Invoices & Receipts", icon: FileText, ownerOnly: false },
  { key: "returns", label: "Returns & Exchanges", icon: RotateCcw, ownerOnly: false },
  { key: "stockadjust", label: "Stock Adjustment", icon: Wrench, ownerOnly: true },
  { key: "purchases", label: "Purchase History", icon: Receipt, ownerOnly: true },
  { key: "loanTracker", label: "Loan / Byaj Khata", icon: Percent, ownerOnly: true },
  { key: "saleshistory", label: "Sales Breakdown & P&L", icon: TrendingUp, ownerOnly: true },
  { key: "plDashboard", label: "Profit & Loss Dashboard", icon: TrendingUp, ownerOnly: true },
  { key: "lowstock", label: "Low Stock & Reorder Alerts", icon: Shield, ownerOnly: false },
  { key: "loyalty", label: "Loyalty & Rewards", icon: Sparkles, ownerOnly: false },
  { key: "dailyreview", label: "Daily Review", icon: Calendar, ownerOnly: true },
  { key: "monthlyreview", label: "Monthly Review", icon: TrendingUp, ownerOnly: true },
  { key: "expShop", label: "Shop Expenses", icon: DollarSign, ownerOnly: true },
  { key: "extraIncome", label: "Extra Income", icon: TrendingUp, ownerOnly: true },
  { key: "expPersonal", label: "Personal Drawings", icon: User, ownerOnly: true },
  { key: "ownerreports", label: "Owner Financial Reports", icon: Shield, ownerOnly: true },
  { key: "staffAccess", label: "Staff Access Manager", icon: Users, ownerOnly: true },
  { key: "backup", label: "Backup & Restore", icon: Save, ownerOnly: true },
  { key: "settings", label: "Shop Settings", icon: SettingsIcon, ownerOnly: true },
];

export const THEME_OPTIONS = [
  { value: "obsidian-orange", label: "Obsidian Orange" },
  { value: "arctic-white", label: "Arctic White" },
  { value: "sand-sage", label: "Sand & Sage" },
  { value: "monograph", label: "Editorial Monograph" },
  { value: "platinum-white", label: "Platinum White" },
  { value: "pearl-blue", label: "Pearl Blue" },
  { value: "graphite-silver", label: "Graphite Silver" },
  { value: "linen-studio", label: "Linen Studio" },
  { value: "minimal-white", label: "Minimal White" },
  { value: "studio-contrast", label: "Studio Contrast" },
];

export const Sidebar: React.FC<SidebarProps> = ({
  db,
  currentPage,
  onNavigate,
  ownerMode,
  onToggleOwnerMode,
  onThemeChange,
  onOpenQuickScan,
  onOpenWindowsModal,
}) => {
  const [showAllTools, setShowAllTools] = useState<boolean>(false);
  const [easyMode, setEasyMode] = useState<boolean>(false);

  const lowStockCount = db.products.filter((p) => p.stock <= p.minStock).length;
  const dueCount = db.customers.filter((c) => (c.totalDue || 0) > 0).length;
  const openJobs = db.jobs.filter((j) => j.status !== "Delivered").length;
  const pendingSimComm = (db.simActivations || []).filter(
    (s) => s.commissionStatus === "Pending from DLR"
  ).length;
  const pendingFinance = db.sales.filter(
    (s) => s.isFinance && s.financeDetails?.payoutStatus === "Pending Bank Settlement"
  ).length;

  // Calculate live daily cash estimated in galla
  const todaySales = db.sales.filter((s) => s.date === todayStr() && !s.isFinance && s.payment === "Cash");
  const todaySalesCash = todaySales.reduce((a, s) => a + s.amountPaid, 0);
  const todayXeroxCash = (db.xeroxEntries || [])
    .filter((x) => x.date === todayStr() && x.paymentMethod === "Cash")
    .reduce((a, x) => a + x.totalAmount, 0);
  const todayGallaCash = (db.settings.openingCashDefault || 5000) + todaySalesCash + todayXeroxCash;

  const isCurrentSecondary = SECONDARY_NAV_ITEMS.some((s) => s.key === currentPage);

  return (
    <aside id="sidebar">
      {/* Brand Header */}
      <div className="brand" style={{ cursor: "pointer" }} onClick={() => onNavigate("dashboard")}>
        <div className="logo-badge" id="brandLogoBadge">
          {db.settings.logo ? (
            <img src={db.settings.logo} alt="Logo" />
          ) : (
            (db.settings.shopName || "DS").trim().slice(0, 2).toUpperCase()
          )}
        </div>
        <div>
          <div className="name" id="brandNameText">
            {db.settings.shopName || "DS MOBILE"}
          </div>
          <div className="tag" style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <span>Digital Retail OS</span>
            {easyMode && (
              <span style={{ background: "var(--green)", color: "#fff", padding: "1px 5px", borderRadius: "4px", fontSize: "8.5px" }}>
                
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Quick Camera Barcode & AI Scan Button */}
      <div style={{ padding: "10px 14px 4px 14px" }}>
        <button
          className="btn primary sm"
          style={{
            width: "100%",
            justifyContent: "center",
            background: "var(--accent)",
            padding: "9px",
            fontSize: "12.5px",
            fontWeight: 800,
          }}
          onClick={onOpenQuickScan}
        >
          <Camera size={15} /> 1-Tap Barcode / Box Scan
        </button>
      </div>

      {/* Navigation List */}
      <nav className="nav" id="navList">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 8px 2px" }}>
          <span className="grp-label" style={{ padding: 0 }}>
            {easyMode ? "⚡ Daily Counter ()" : "📌 Main Tasks"}
          </span>
          <button
            onClick={() => setEasyMode(!easyMode)}
            style={{
              background: easyMode ? "var(--green-light)" : "transparent",
              color: easyMode ? "var(--green)" : "var(--sidebar-text)",
              border: "1px solid",
              borderColor: easyMode ? "var(--green-border)" : "var(--sidebar-border)",
              fontSize: "10px",
              padding: "2px 7px",
              borderRadius: "6px",
              cursor: "pointer",
              fontWeight: 700,
            }}
          >
            {easyMode ? "✓ Easy Mode ON" : " "}
          </button>
        </div>

        {/* Primary Counter Navigation — Staff view is restricted to Sales only */}
        {(ownerMode ? PRIMARY_NAV_ITEMS : PRIMARY_NAV_ITEMS.filter((i) => i.key === "sell")).map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.key;
          let badgeCount = 0;
          if (item.key === "khata" && dueCount > 0) badgeCount = dueCount;
          if (item.key === "jobs" && openJobs > 0) badgeCount = openJobs;

          return (
            <button
              key={item.key}
              className={`navitem ${isActive ? "active" : ""}`}
              onClick={() => onNavigate(item.key)}
            >
              <span className="ic">
                <Icon size={16} />
              </span>
              <span style={{ fontSize: "13px" }}>{item.label}</span>
              {badgeCount > 0 && <span className="badge-dot">{badgeCount}</span>}
            </button>
          );
        })}

        {/* Secondary / Advanced Section — Owner only */}
        {!easyMode && ownerMode && (
          <div style={{ marginTop: "6px", borderTop: "1px solid var(--sidebar-border)", paddingTop: "6px" }}>
            <button
              onClick={() => setShowAllTools(!showAllTools || isCurrentSecondary)}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: "rgba(255,255,255,0.03)",
                border: "none",
                color: "var(--sidebar-text)",
                padding: "8px 10px",
                borderRadius: "6px",
                fontSize: "11px",
                fontWeight: 800,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                cursor: "pointer",
              }}
            >
              <span>More Tools &amp; Reports ({SECONDARY_NAV_ITEMS.length})</span>
              {showAllTools || isCurrentSecondary ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>

            {(showAllTools || isCurrentSecondary) && (
              <div style={{ marginTop: "4px", display: "flex", flexDirection: "column", gap: "2px" }}>
                {SECONDARY_NAV_ITEMS.filter((n) => !n.ownerOnly || ownerMode).map((item) => {
                  const Icon = item.icon;
                  const isActive = currentPage === item.key;
                  let badgeCount = 0;
                  if (item.key === "products" && lowStockCount > 0) badgeCount = lowStockCount;
                  if (item.key === "simTracker" && pendingSimComm > 0) badgeCount = pendingSimComm;
                  if (item.key === "financeLedger" && pendingFinance > 0) badgeCount = pendingFinance;

                  return (
                    <button
                      key={item.key}
                      className={`navitem ${isActive ? "active" : ""}`}
                      onClick={() => onNavigate(item.key)}
                      style={{ fontSize: "12px", padding: "7px 10px" }}
                    >
                      <span className="ic">
                        <Icon size={14} />
                      </span>
                      <span>{item.label}</span>
                      {badgeCount > 0 && <span className="badge-dot">{badgeCount}</span>}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </nav>

      {/* Daily Galla Status Meter — Owner only */}
      {ownerMode && (
      <div
        style={{
          padding: "10px 14px",
          background: "var(--sidebar-footer-bg)",
          borderTop: "1px solid var(--sidebar-border)",
          cursor: "pointer",
        }}
        onClick={() => onNavigate("gallaClosing")}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "4px" }}>
          <span style={{ fontSize: "10px", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--sidebar-text)" }}>
            Daily Galla ()
          </span>
          <span style={{ color: "var(--green)", fontFamily: "var(--font-mono)", fontSize: "13px", fontWeight: 800 }}>
            {inr(todayGallaCash)}
          </span>
        </div>
        <div style={{ height: "4px", width: "100%", background: "#1e293b", borderRadius: "999px", overflow: "hidden" }}>
          <div
            style={{
              width: `${Math.min(100, Math.max(15, (todayGallaCash / 50000) * 100))}%`,
              height: "100%",
              background: "var(--green)",
              borderRadius: "999px",
            }}
          />
        </div>
      </div>
      )}

      {/* Footer Controls */}
      <div className="mode-box" style={{ padding: "10px 14px" }}>
        {false && (
          <button
            className="btn sm"
            style={{
              width: "100%",
              marginBottom: "8px",
              justifyContent: "center",
              background: "var(--card)",
              color: "var(--ink)",
              border: "1px solid var(--sidebar-border)",
              padding: "6px 8px",
              fontSize: "11px",
              fontWeight: 800,
            }}
            onClick={onOpenWindowsModal}
          >
            <Monitor size={13} style={{ color: "var(--accent)" }} /> 💻 Windows Desktop App
          </button>
        )}

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "6px" }}>
          <div className="theme-label" style={{ margin: 0 }}>Theme</div>
          <select
            className="theme-toggle"
            id="btnThemeToggle"
            style={{ width: "auto", padding: "3px 6px", fontSize: "11px" }}
            value={db.settings.theme || "obsidian-orange"}
            onChange={(e) => onThemeChange(e.target.value)}
          >
            {THEME_OPTIONS.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>

        <div className="mode-pill">
          <button
            id="btnStaffMode"
            className={!ownerMode ? "on" : ""}
            onClick={() => {
              if (ownerMode) onToggleOwnerMode();
            }}
          >
            Staff ()
          </button>
          <button
            id="btnOwnerMode"
            className={ownerMode ? "on" : ""}
            onClick={() => {
              if (!ownerMode) onToggleOwnerMode();
            }}
          >
            Owner ()
          </button>
        </div>
      </div>
    </aside>
  );
};
