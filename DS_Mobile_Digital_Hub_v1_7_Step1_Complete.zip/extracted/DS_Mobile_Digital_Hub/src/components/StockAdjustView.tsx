import React, { useState } from "react";
import { Wrench, Plus, CheckCircle2, AlertTriangle, ArrowUpDown, History } from "lucide-react";
import { Database, Product } from "../types";
import { todayStr, nowTimeStr, uid, addStockBatch, consumeFIFO } from "../utils/fifoEngine";
import { supabase, isCloudConfigured } from "../services/supabaseClient";
import { queueOfflineOperation } from "../services/repository";

interface StockAdjustViewProps {
  db: Database;
  storeId?: string;
  onUpdate: () => void;
  toast: (msg: string, type?: "green" | "red" | "amber") => void;
}

// Server-side rejections (bad delta, unknown product, no permission) will
// fail again on retry — queuing those would spam the offline queue forever.
// Only network/availability errors get queued for the background worker.
function isBusinessRejection(message: string): boolean {
  return /invalid quantity|not authorized|unknown product/i.test(message);
}

export const StockAdjustView: React.FC<StockAdjustViewProps> = ({
  db,
  storeId,
  onUpdate,
  toast,
}) => {
  const [selectedProductId, setSelectedProductId] = useState("");
  const [adjustType, setAdjustType] = useState<"SET_EXACT" | "ADD" | "SUBTRACT">("SET_EXACT");
  const [quantityInput, setQuantityInput] = useState<number>(0);
  const [reason, setReason] = useState("Physical Inventory Audit Count");
  const [notes, setNotes] = useState("");
  const [filterSearch, setFilterSearch] = useState("");

  const selectedProduct = db.products.find((p) => p.id === selectedProductId);

  const calculateNewStock = () => {
    if (!selectedProduct) return 0;
    if (adjustType === "SET_EXACT") return Math.max(0, quantityInput);
    if (adjustType === "ADD") return selectedProduct.stock + Math.max(0, quantityInput);
    if (adjustType === "SUBTRACT") return Math.max(0, selectedProduct.stock - Math.max(0, quantityInput));
    return selectedProduct.stock;
  };

  const [isSavingAdjustment, setIsSavingAdjustment] = useState(false);

  const handleApplyAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) {
      toast("Please select a product to adjust", "red");
      return;
    }

    const previousStock = selectedProduct.stock;
    const newStock = calculateNewStock();
    const delta = newStock - previousStock;

    if (delta === 0) {
      toast("No change in stock quantity", "amber");
      return;
    }

    setIsSavingAdjustment(true);
    try {
      const idempotencyKey = crypto.randomUUID();

      // Cloud side: commit the correction + FIFO batch consume/open + stock
      // update atomically in Postgres (mirrors Purchases/Sales). Falls back
      // to the offline queue on any network/availability failure; the local
      // ledger below is always written either way and stays the offline cache.
      if (isCloudConfigured && storeId) {
        try {
          const { error } = await supabase.rpc("atomic_apply_stock_adjustment", {
            p_store_id: storeId,
            p_product_id: selectedProduct.id,
            p_delta: delta,
            p_reason: reason,
            p_idempotency_key: idempotencyKey,
          });
          if (error) throw error;
        } catch (err: any) {
          const msg = String(err?.message || err || "");
          if (isBusinessRejection(msg)) {
            toast(msg || "Adjustment rejected by server.", "red");
            return;
          }
          try {
            await queueOfflineOperation(
              "stock_adjustment",
              "stock_movements",
              { adjustment: { productId: selectedProduct.id, delta, reason } },
              idempotencyKey
            );
          } catch {
            toast("Adjustment could not be safely queued. Please retry.", "red");
            return;
          }
        }
      }

      selectedProduct.stock = newStock;

      // BUG FIX: adjustments used to only touch product.stock, never the FIFO
      // stockBatches. That desyncs the two, and later sales either wrongly
      // fail with "Insufficient stock / inventory mismatch" (batches short of
      // what stock claims) or silently under-cost sales (stock short of what
      // batches claim). Mirror the delta into stockBatches, same as
      // Purchases/Returns/KYC do.
      if (delta > 0) {
        addStockBatch(db, selectedProduct.id, delta, selectedProduct.purchasePrice || 0, todayStr(), {
          source: "adjustment",
          ref: reason,
        });
      } else if (delta < 0) {
        try {
          consumeFIFO(db, selectedProduct.id, Math.abs(delta));
        } catch (error) {
          console.error("Stock adjustment FIFO consumption failed", error);
          // Batches already didn't cover the reduction — nothing more to
          // consume, but the product.stock correction above still applies.
        }
      }

      const adjustmentEntry = {
        id: uid("adj"),
        productId: selectedProduct.id,
        productName: selectedProduct.name,
        previousStock,
        newStock,
        delta,
        reason,
        notes,
        date: todayStr(),
        time: nowTimeStr(),
        createdAt: new Date().toISOString(),
      };

      if (!db.stockAdjustments) {
        db.stockAdjustments = [];
      }
      db.stockAdjustments.push(adjustmentEntry);

      onUpdate();
      toast(`Stock for ${selectedProduct.name} updated: ${previousStock} ➔ ${newStock}`, "green");
      setQuantityInput(0);
      setNotes("");
    } finally {
      setIsSavingAdjustment(false);
    }
  };

  const filteredHistory = (db.stockAdjustments || []).filter((a: any) => {
    if (!filterSearch) return true;
    const q = filterSearch.toLowerCase();
    return (
      a.productName?.toLowerCase().includes(q) ||
      a.reason?.toLowerCase().includes(q) ||
      a.notes?.toLowerCase().includes(q)
    );
  });

  return (
    <div>
      <div className="section">
        <div className="section-head">
          <div>
            <h2>⚙️ Stock Adjustment &amp; Physical Audit</h2>
            <span style={{ fontSize: "12px", color: "var(--ink-soft)" }}>
              Manually correct physical inventory counts, write off damaged/broken goods, or reconcile stock discrepancies
            </span>
          </div>
        </div>

        <form onSubmit={handleApplyAdjustment} style={{ background: "var(--paper)", padding: "18px", borderRadius: "10px", marginBottom: "20px" }}>
          <div className="formgrid">
            <div className="field full">
              <label>Select Product to Adjust</label>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  setSelectedProductId(e.target.value);
                  const p = db.products.find((x) => x.id === e.target.value);
                  if (p) setQuantityInput(p.stock);
                }}
                required
              >
                <option value="">-- Choose Product from Inventory --</option>
                {db.products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.category}) — Current Stock: {p.stock} {p.sku ? `[${p.sku}]` : ""}
                  </option>
                ))}
              </select>
            </div>

            {selectedProduct && (
              <>
                <div className="field">
                  <label>Adjustment Mode</label>
                  <select value={adjustType} onChange={(e) => setAdjustType(e.target.value as any)}>
                    <option value="SET_EXACT">Set Exact Physical Count</option>
                    <option value="ADD">+ Add Stock / Found Extra</option>
                    <option value="SUBTRACT">- Subtract Stock / Damage / Loss (/)</option>
                  </select>
                </div>

                <div className="field">
                  <label>
                    {adjustType === "SET_EXACT" ? "Actual Physical Count in Shop" : "Adjustment Quantity"}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={quantityInput}
                    onChange={(e) => setQuantityInput(Number(e.target.value) || 0)}
                    required
                  />
                </div>

                <div className="field">
                  <label>Reason for Adjustment</label>
                  <select value={reason} onChange={(e) => setReason(e.target.value)}>
                    <option>Physical Inventory Audit Count</option>
                    <option>Damaged / Broken in Shop Display</option>
                    <option>Defective / Vendor Warranty Return</option>
                    <option>Theft / Shrinkage Loss</option>
                    <option>Given as Free Sample / Promo</option>
                    <option>Data Entry Mistake Correction</option>
                  </select>
                </div>

                <div className="field">
                  <label>Audit Notes / Remarks</label>
                  <input
                    placeholder="e.g. Counted during Sunday audit"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>

                <div className="field full" style={{ marginTop: "6px" }}>
                  <div
                    style={{
                      background: "var(--card)",
                      padding: "12px 16px",
                      borderRadius: "8px",
                      border: "1px solid var(--line)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <div>
                      <span style={{ fontSize: "12px", color: "var(--ink-soft)" }}>Stock Summary:</span>
                      <div style={{ fontSize: "15px", fontWeight: 700, marginTop: "2px" }}>
                        Current System Stock: <b>{selectedProduct.stock}</b> ➔ New Stock:{" "}
                        <b style={{ color: "var(--blue)" }}>{calculateNewStock()}</b>{" "}
                        <span style={{ fontSize: "12.5px", color: calculateNewStock() - selectedProduct.stock >= 0 ? "var(--green)" : "var(--red)" }}>
                          ({calculateNewStock() - selectedProduct.stock >= 0 ? `+${calculateNewStock() - selectedProduct.stock}` : calculateNewStock() - selectedProduct.stock})
                        </span>
                      </div>
                    </div>

                    <button type="submit" className="btn primary" disabled={isSavingAdjustment}>
                      <CheckCircle2 size={16} /> {isSavingAdjustment ? "Saving..." : "Save Stock Adjustment"}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </form>

        {/* Audit Log Table */}
        <div className="section-head" style={{ marginTop: "16px" }}>
          <h3>📋 Stock Adjustment History Log ({filteredHistory.length})</h3>
          <input
            placeholder="Search audit log..."
            value={filterSearch}
            onChange={(e) => setFilterSearch(e.target.value)}
            style={{ maxWidth: "240px", padding: "6px 10px" }}
          />
        </div>

        <div className="table-wrap">
          {filteredHistory.length === 0 ? (
            <div className="empty">No stock adjustments recorded yet.</div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Date &amp; Time</th>
                  <th>Product</th>
                  <th>Old Stock</th>
                  <th>Change (Delta)</th>
                  <th>New Stock</th>
                  <th>Reason</th>
                  <th>Notes</th>
                </tr>
              </thead>
              <tbody>
                {filteredHistory.slice().reverse().map((a: any) => (
                  <tr key={a.id}>
                    <td>{a.date} {a.time}</td>
                    <td><b>{a.productName}</b></td>
                    <td>{a.previousStock}</td>
                    <td>
                      <b style={{ color: a.delta >= 0 ? "var(--green)" : "var(--red)" }}>
                        {a.delta >= 0 ? `+${a.delta}` : a.delta}
                      </b>
                    </td>
                    <td><b>{a.newStock}</b></td>
                    <td><span className="badge info">{a.reason}</span></td>
                    <td className="hint">{a.notes || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
