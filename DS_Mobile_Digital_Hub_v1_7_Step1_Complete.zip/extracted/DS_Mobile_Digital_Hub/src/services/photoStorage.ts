// Architecture improvement: product photos used to be stored as compressed
// base64 JPEG strings directly inside Product.photo, which lives inside the
// single store_state JSON blob that syncs on every save. That meant editing
// one product's stock count re-uploaded every product's photo, every time —
// slow and failure-prone on weak mobile data.
//
// This service uploads the photo to the `product-photos` Supabase Storage
// bucket instead, and the caller stores only the returned public URL string
// in Product.photo. The field name/type on Product is unchanged, so nothing
// else that reads product.photo (invoices, barcode labels, product cards)
// needs to change — a URL renders in an <img src=...> exactly like a data:
// URL did.
import { supabase, isCloudConfigured } from "./supabaseClient";
import { compressImageToBlob } from "../utils/imageCompress";
import { Database } from "../types";

const BUCKET = "product-photos";

export function isStorageUrl(value: string | undefined | null): boolean {
  return !!value && !value.startsWith("data:");
}

// Uploads one already-compressed Blob for a given store+product and returns
// its public URL. Throws on failure (offline, RLS, etc.) — callers decide
// the fallback (see uploadProductPhotoOrFallback below).
export async function uploadProductPhotoBlob(
  storeId: string,
  productId: string,
  blob: Blob
): Promise<string> {
  const path = `${storeId}/${productId}-${Date.now()}.jpg`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, blob, {
    contentType: "image/jpeg",
    cacheControl: "31536000", // photos are immutable once uploaded (new path each time) — cache hard
    upsert: false,
  });
  if (error) throw error;
  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

// Compress + upload in one call. If cloud isn't configured or the upload
// fails (offline, RLS not synced yet, etc.), falls back to the old
// data-URL-in-state behaviour so the photo feature never breaks — it just
// stays "unmigrated" for that one photo until the next successful sync,
// when the background backfill below picks it up.
export async function uploadProductPhotoOrFallback(
  storeId: string | undefined,
  productId: string,
  file: File | Blob
): Promise<{ url: string; uploaded: boolean }> {
  const blob = await compressImageToBlob(file);
  if (!isCloudConfigured || !storeId) {
    return { url: await blobToDataUrl(blob), uploaded: false };
  }
  try {
    const url = await uploadProductPhotoBlob(storeId, productId, blob);
    return { url, uploaded: true };
  } catch {
    return { url: await blobToDataUrl(blob), uploaded: false };
  }
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("Photo read fail ho gaya"));
    reader.readAsDataURL(blob);
  });
}

// Best-effort delete of a previously-uploaded photo (e.g. when a product's
// photo is replaced or removed). Never throws — an orphaned file in Storage
// costs a few KB and is not worth failing the user's save over.
export async function deleteProductPhotoByUrl(url: string | undefined): Promise<void> {
  if (!isStorageUrl(url)) return;
  try {
    const marker = `/${BUCKET}/`;
    const idx = url!.indexOf(marker);
    if (idx === -1) return;
    const path = decodeURIComponent(url!.slice(idx + marker.length).split("?")[0]);
    await supabase.storage.from(BUCKET).remove([path]);
  } catch {
    // best-effort — ignore
  }
}

// Backfill: on any store that still has legacy base64 photos sitting in
// state (from before this migration, or saved while offline), upload them
// one at a time in the background and replace the field with the resulting
// URL. Called opportunistically whenever the app is online and idle (see
// App.tsx's connectivity-sync effect) — never blocks the UI, never runs
// more than one upload at a time, and gives up quietly on any single photo
// that fails so one bad image can't stall the rest.
let backfillRunning = false;
export async function backfillLegacyProductPhotos(
  storeId: string | undefined,
  db: Database,
  onProductPhotoMigrated: (productId: string, url: string) => void
): Promise<void> {
  if (!isCloudConfigured || !storeId || backfillRunning) return;
  const pending = (db.products || []).filter((p) => p.photo && p.photo.startsWith("data:"));
  if (!pending.length) return;
  backfillRunning = true;
  try {
    for (const product of pending) {
      try {
        const res = await fetch(product.photo);
        const blob = await res.blob();
        const url = await uploadProductPhotoBlob(storeId, product.id, blob);
        onProductPhotoMigrated(product.id, url);
      } catch {
        // leave this one as data: URL — will retry on the next backfill pass
      }
    }
  } finally {
    backfillRunning = false;
  }
}
