import { supabase } from "../services/supabaseClient";

// Every AI endpoint on the server requires a logged-in Supabase user
// (requireSupabaseUser in server.ts). Earlier this file's fetch calls never
// attached the session token, so every AI scan silently 401'd and the app
// fell back to "AI unavailable — enter manually." even with valid API keys
// configured. This helper is now used by every call in this file.
async function authHeaders(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const token = data?.session?.access_token;
  return { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) };
}

export interface OcrPhoneResult {
  brand: string;
  modelName: string;
  imei1: string;
  imei2?: string;
  serialNo?: string;
  color?: string;
  ramStorage?: string;
  mrp?: number;
  sellingPriceSuggested?: number;
  androidVersion?: string;
  batteryHealth?: string;
  detectedCategory: "New Mobile" | "Second-Hand Mobile" | "Accessory";
  notes?: string;
  rawConfidence?: string;
  verified?: boolean;
  requiresVerification?: boolean;
  mismatches?: string[];
  rawText?: string;
}

export interface OcrAccessoryResult {
  brand: string;
  productName: string;
  category: string;
  compatibleModels: string[];
  notes?: string;
  screenSizeInches?: number;
}

// Asks the AI for a phone model's screen size (inches) — used as a fallback
// match in ModelSearchView when a customer's exact model isn't listed under
// any glass/cover's compatibleModels.
export async function lookupScreenSize(modelName: string): Promise<number> {
  const res = await fetch("/api/screen-size-lookup", {
    method: "POST",
    headers: await authHeaders(),
    body: JSON.stringify({ modelName }),
  });
  if (res.ok) {
    const json = await res.json();
    if (json.success) return Number(json.screenSizeInches) || 0;
  }
  return 0;
}

// Scans an accessory pack photo (tempered glass / back cover / charger /
// cable box) and returns the brand, product name, suggested category and the
// FULL list of compatible phone models printed on it. Used to auto-fill the
// "Add New Product" form so one photo -> one catalog item with many models,
// instead of the staff typing every model by hand.
export async function processAccessoryOcr(imageDataUrl: string): Promise<OcrAccessoryResult> {
  const res = await fetch("/api/ocr-accessory", {
    method: "POST",
    headers: await authHeaders(),
    body: JSON.stringify({ image: imageDataUrl }),
  });

  if (res.ok) {
    const json = await res.json();
    if (json.success && json.data) {
      return {
        brand: json.data.brand || "",
        productName: json.data.productName || "",
        category: json.data.category || "Accessories",
        compatibleModels: Array.isArray(json.data.compatibleModels) ? json.data.compatibleModels : [],
        notes: json.data.notes || "",
        screenSizeInches: Number(json.data.screenSizeInches) || 0,
      };
    }
  }
  const msg = await res.json().catch(() => null);
  throw new Error(msg?.error || "AI unavailable — enter manually.");
}

export interface ProductPhotoResult {
  itemType: string;
  brand: string;
  productName: string;
  color: string;
  searchKeywords: string[];
  notes?: string;
}

// Identifies ANY shop item from a photo (phone, glass, cover, charger,
// cable, earphones, power bank, etc.) and returns short search keywords the
// client uses to search the shop's OWN product catalog — used by the staff
// "Photo Stock Finder" so a staff member can snap a photo of something and
// jump straight to matching in-stock items to sell, instead of typing.
export async function identifyProductPhoto(imageDataUrl: string): Promise<ProductPhotoResult> {
  const res = await fetch("/api/product-photo-search", {
    method: "POST",
    headers: await authHeaders(),
    body: JSON.stringify({ image: imageDataUrl }),
  });

  if (res.ok) {
    const json = await res.json();
    if (json.success && json.data) {
      return {
        itemType: json.data.itemType || "",
        brand: json.data.brand || "",
        productName: json.data.productName || "",
        color: json.data.color || "",
        searchKeywords: Array.isArray(json.data.searchKeywords) ? json.data.searchKeywords : [],
        notes: json.data.notes || "",
      };
    }
  }
  const msg = await res.json().catch(() => null);
  throw new Error(msg?.error || "AI unavailable — search manually.");
}

export async function processPhoneOcr(
  imageDataUrl: string,
  imageType: "box" | "about_screen" | "auto" = "auto"
): Promise<OcrPhoneResult> {
  try {
    const res = await fetch("/api/ocr-phone", {
      method: "POST",
      headers: await authHeaders(),
      body: JSON.stringify({ image: imageDataUrl, imageType }),
    });

    if (res.ok) {
      const json = await res.json();
      if (json.success && json.data) {
        return {
          brand: json.data.brand || "",
          modelName: json.data.modelName || "",
          imei1: (json.data.imei1 || "").replace(/\D/g, "").slice(0, 15),
          imei2: (json.data.imei2 || "").replace(/\D/g, "").slice(0, 15),
          serialNo: json.data.serialNo || "",
          color: json.data.color || "",
          ramStorage: json.data.ramStorage || "",
          mrp: Number(json.data.mrp) || 0,
          sellingPriceSuggested: Number(json.data.sellingPriceSuggested) || 0,
          androidVersion: json.data.androidVersion || "",
          batteryHealth: json.data.batteryHealth || "",
          detectedCategory: json.data.detectedCategory || (imageType === "about_screen" ? "Second-Hand Mobile" : "New Mobile"),
          notes: json.data.notes || "",
          rawConfidence: json.provider || "AI Vision",
          verified: Boolean(json.verified),
          requiresVerification: Boolean(json.requiresVerification),
          mismatches: Array.isArray(json.mismatches) ? json.mismatches : [],
          rawText: json.rawText || "",
        };
      }
    }
  } catch (err) {
    console.warn("AI/OCR service unavailable:", err);
  }
  throw new Error("AI unavailable — enter manually.");

}

