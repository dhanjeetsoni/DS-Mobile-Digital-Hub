import { Database, StockBatch } from "../types";
import { round2 } from "./indianCurrency";

export function uid(prefix: string): string {
  // UUID-backed identifiers avoid collisions across tabs/devices.
  return `${prefix}_${crypto.randomUUID()}`;
}

export function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

export function nowTimeStr(): string {
  return new Date().toTimeString().slice(0, 5);
}

export function genSku(prefix = "DSM"): string {
  // Collision-resistant client candidate. The database must still enforce UNIQUE(sku).
  return `${prefix}${crypto.randomUUID().replace(/-/g, "").slice(0, 10).toUpperCase()}`;
}

// Generates a scannable 12-digit numeric barcode (EAN-13 style, self-check
// digit) for a brand-new product. Saved on the product once and reused for
// every future POS scan of that item.
export function genBarcode(): string {
  let digits = "2"; // "2" prefix = in-store generated code, never collides with real manufacturer EAN codes
  for (let i = 0; i < 11; i++) digits += Math.floor(Math.random() * 10);
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    sum += Number(digits[i]) * (i % 2 === 0 ? 1 : 3);
  }
  const checkDigit = (10 - (sum % 10)) % 10;
  return digits + checkDigit;
}

export function addStockBatch(
  db: Database,
  productId: string,
  qty: number,
  purchasePrice: number,
  date: string,
  meta?: { supplier?: string; source?: string; ref?: string }
): StockBatch {
  const b: StockBatch = {
    id: uid("batch"),
    productId,
    qty: Number(qty) || 0,
    remainingQty: Number(qty) || 0,
    purchasePrice: Number(purchasePrice) || 0,
    date: date || todayStr(),
    supplier: meta?.supplier || "",
    source: meta?.source || "purchase",
    ref: meta?.ref || "",
    createdAt: new Date().toISOString(),
  };
  db.stockBatches.push(b);
  return b;
}

export function getBatchesForProduct(db: Database, productId: string): StockBatch[] {
  return db.stockBatches
    .filter((b) => b.productId === productId && b.remainingQty > 0.0001)
    .sort((a, b) =>
      a.date < b.date ? -1 : a.date > b.date ? 1 : a.createdAt < b.createdAt ? -1 : 1
    );
}

export function consumeFIFO(
  db: Database,
  productId: string,
  qty: number
): { batchId: string | null; qty: number; purchasePrice: number }[] {
  let remaining = round2(qty);
  const consumed: { batchId: string | null; qty: number; purchasePrice: number }[] = [];
  for (const b of getBatchesForProduct(db, productId)) {
    if (remaining <= 0.0001) break;
    const take = Math.min(b.remainingQty, remaining);
    b.remainingQty = round2(b.remainingQty - take);
    consumed.push({ batchId: b.id, qty: take, purchasePrice: b.purchasePrice });
    remaining = round2(remaining - take);
  }
  if (remaining > 0.0001) {
    throw new Error("Insufficient stock / inventory mismatch.");
  }
  return consumed;
}

export function fifoCostTotal(
  consumed?: { batchId: string | null; qty: number; purchasePrice: number }[]
): number {
  return round2((consumed || []).reduce((a, c) => a + (c.purchasePrice || 0) * c.qty, 0));
}
